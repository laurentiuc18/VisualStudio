﻿
namespace CarreraV3
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nombreLabel;
            System.Windows.Forms.Label apellidoLabel;
            System.Windows.Forms.Label fechaNacimientoLabel;
            System.Windows.Forms.Label tiempoCarreraLabel;
            System.Windows.Forms.Label dNILabel;
            System.Windows.Forms.Label sexoLabel;
            System.Windows.Forms.Label tallaDeCamisaLabel;
            System.Windows.Forms.Label nombreCamisetaLabel;
            System.Windows.Forms.Label insripcionSolidariaLabel;
            System.Windows.Forms.Label recibirNoticiasLabel;
            this.Guardar = new System.Windows.Forms.Button();
            this.CarreraDataGreed = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellidoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaNacimientoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tiempoCarreraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dNIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sexoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tallaDeCamisaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreCamisetaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.insripcionSolidariaDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.recibirNoticiasDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.atletismoBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.atletasDataSet = new CarreraV3.AtletasDataSet();
            this.atletismoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.atletismoTableAdapter = new CarreraV3.AtletasDataSetTableAdapters.AtletismoTableAdapter();
            this.tableAdapterManager = new CarreraV3.AtletasDataSetTableAdapters.TableAdapterManager();
            this.nombreTextBox = new System.Windows.Forms.TextBox();
            this.apellidoTextBox = new System.Windows.Forms.TextBox();
            this.fechaNacimientoDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.tiempoCarreraTextBox = new System.Windows.Forms.TextBox();
            this.dNITextBox = new System.Windows.Forms.TextBox();
            this.nombreCamisetaTextBox = new System.Windows.Forms.TextBox();
            this.insripcionSolidariaCheckBox = new System.Windows.Forms.CheckBox();
            this.recibirNoticiasCheckBox = new System.Windows.Forms.CheckBox();
            this.Seleccion = new System.Windows.Forms.ComboBox();
            this.btnVer = new System.Windows.Forms.Button();
            this.seleccion2 = new System.Windows.Forms.ComboBox();
            this.Eliminar = new System.Windows.Forms.Button();
            this.comboSexo = new System.Windows.Forms.ComboBox();
            this.comboTallaCamisa = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.editarDatoss = new System.Windows.Forms.Button();
            this.btnNuevoUsuario = new System.Windows.Forms.Button();
            this.atletismoDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Patrocinadores = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            nombreLabel = new System.Windows.Forms.Label();
            apellidoLabel = new System.Windows.Forms.Label();
            fechaNacimientoLabel = new System.Windows.Forms.Label();
            tiempoCarreraLabel = new System.Windows.Forms.Label();
            dNILabel = new System.Windows.Forms.Label();
            sexoLabel = new System.Windows.Forms.Label();
            tallaDeCamisaLabel = new System.Windows.Forms.Label();
            nombreCamisetaLabel = new System.Windows.Forms.Label();
            insripcionSolidariaLabel = new System.Windows.Forms.Label();
            recibirNoticiasLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.CarreraDataGreed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.atletismoBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.atletasDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.atletismoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.atletismoDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // nombreLabel
            // 
            nombreLabel.AutoSize = true;
            nombreLabel.Location = new System.Drawing.Point(97, 46);
            nombreLabel.Name = "nombreLabel";
            nombreLabel.Size = new System.Drawing.Size(62, 17);
            nombreLabel.TabIndex = 23;
            nombreLabel.Text = "Nombre:";
            // 
            // apellidoLabel
            // 
            apellidoLabel.AutoSize = true;
            apellidoLabel.Location = new System.Drawing.Point(97, 84);
            apellidoLabel.Name = "apellidoLabel";
            apellidoLabel.Size = new System.Drawing.Size(62, 17);
            apellidoLabel.TabIndex = 24;
            apellidoLabel.Text = "Apellido:";
            // 
            // fechaNacimientoLabel
            // 
            fechaNacimientoLabel.AutoSize = true;
            fechaNacimientoLabel.Location = new System.Drawing.Point(97, 122);
            fechaNacimientoLabel.Name = "fechaNacimientoLabel";
            fechaNacimientoLabel.Size = new System.Drawing.Size(125, 17);
            fechaNacimientoLabel.TabIndex = 25;
            fechaNacimientoLabel.Text = "Fecha Nacimiento:";
            // 
            // tiempoCarreraLabel
            // 
            tiempoCarreraLabel.AutoSize = true;
            tiempoCarreraLabel.Location = new System.Drawing.Point(97, 155);
            tiempoCarreraLabel.Name = "tiempoCarreraLabel";
            tiempoCarreraLabel.Size = new System.Drawing.Size(111, 17);
            tiempoCarreraLabel.TabIndex = 26;
            tiempoCarreraLabel.Text = "Tiempo Carrera:";
            // 
            // dNILabel
            // 
            dNILabel.AutoSize = true;
            dNILabel.Location = new System.Drawing.Point(97, 191);
            dNILabel.Name = "dNILabel";
            dNILabel.Size = new System.Drawing.Size(35, 17);
            dNILabel.TabIndex = 27;
            dNILabel.Text = "DNI:";
            // 
            // sexoLabel
            // 
            sexoLabel.AutoSize = true;
            sexoLabel.Location = new System.Drawing.Point(619, 46);
            sexoLabel.Name = "sexoLabel";
            sexoLabel.Size = new System.Drawing.Size(43, 17);
            sexoLabel.TabIndex = 28;
            sexoLabel.Text = "Sexo:";
            // 
            // tallaDeCamisaLabel
            // 
            tallaDeCamisaLabel.AutoSize = true;
            tallaDeCamisaLabel.Location = new System.Drawing.Point(619, 84);
            tallaDeCamisaLabel.Name = "tallaDeCamisaLabel";
            tallaDeCamisaLabel.Size = new System.Drawing.Size(115, 17);
            tallaDeCamisaLabel.TabIndex = 29;
            tallaDeCamisaLabel.Text = "Talla De Camisa:";
            // 
            // nombreCamisetaLabel
            // 
            nombreCamisetaLabel.AutoSize = true;
            nombreCamisetaLabel.Location = new System.Drawing.Point(619, 122);
            nombreCamisetaLabel.Name = "nombreCamisetaLabel";
            nombreCamisetaLabel.Size = new System.Drawing.Size(124, 17);
            nombreCamisetaLabel.TabIndex = 30;
            nombreCamisetaLabel.Text = "Nombre Camiseta:";
            // 
            // insripcionSolidariaLabel
            // 
            insripcionSolidariaLabel.AutoSize = true;
            insripcionSolidariaLabel.Location = new System.Drawing.Point(619, 160);
            insripcionSolidariaLabel.Name = "insripcionSolidariaLabel";
            insripcionSolidariaLabel.Size = new System.Drawing.Size(131, 17);
            insripcionSolidariaLabel.TabIndex = 31;
            insripcionSolidariaLabel.Text = "Insripcion Solidaria:";
            // 
            // recibirNoticiasLabel
            // 
            recibirNoticiasLabel.AutoSize = true;
            recibirNoticiasLabel.Location = new System.Drawing.Point(619, 199);
            recibirNoticiasLabel.Name = "recibirNoticiasLabel";
            recibirNoticiasLabel.Size = new System.Drawing.Size(110, 17);
            recibirNoticiasLabel.TabIndex = 32;
            recibirNoticiasLabel.Text = "Recibir Noticias:";
            // 
            // Guardar
            // 
            this.Guardar.BackColor = System.Drawing.SystemColors.Desktop;
            this.Guardar.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.Guardar.Location = new System.Drawing.Point(248, 270);
            this.Guardar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Guardar.Name = "Guardar";
            this.Guardar.Size = new System.Drawing.Size(200, 60);
            this.Guardar.TabIndex = 23;
            this.Guardar.Text = "Guardar Usuario";
            this.Guardar.UseVisualStyleBackColor = false;
            this.Guardar.Click += new System.EventHandler(this.Guardar_Click);
            // 
            // CarreraDataGreed
            // 
            this.CarreraDataGreed.AutoGenerateColumns = false;
            this.CarreraDataGreed.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CarreraDataGreed.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn,
            this.apellidoDataGridViewTextBoxColumn,
            this.fechaNacimientoDataGridViewTextBoxColumn,
            this.tiempoCarreraDataGridViewTextBoxColumn,
            this.dNIDataGridViewTextBoxColumn,
            this.sexoDataGridViewTextBoxColumn,
            this.tallaDeCamisaDataGridViewTextBoxColumn,
            this.nombreCamisetaDataGridViewTextBoxColumn,
            this.insripcionSolidariaDataGridViewCheckBoxColumn,
            this.recibirNoticiasDataGridViewCheckBoxColumn});
            this.CarreraDataGreed.DataSource = this.atletismoBindingSource1;
            this.CarreraDataGreed.Location = new System.Drawing.Point(33, 398);
            this.CarreraDataGreed.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CarreraDataGreed.Name = "CarreraDataGreed";
            this.CarreraDataGreed.RowHeadersWidth = 51;
            this.CarreraDataGreed.RowTemplate.Height = 24;
            this.CarreraDataGreed.Size = new System.Drawing.Size(975, 196);
            this.CarreraDataGreed.TabIndex = 22;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.Width = 125;
            // 
            // nombreDataGridViewTextBoxColumn
            // 
            this.nombreDataGridViewTextBoxColumn.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nombreDataGridViewTextBoxColumn.Name = "nombreDataGridViewTextBoxColumn";
            this.nombreDataGridViewTextBoxColumn.Width = 125;
            // 
            // apellidoDataGridViewTextBoxColumn
            // 
            this.apellidoDataGridViewTextBoxColumn.DataPropertyName = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.HeaderText = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.apellidoDataGridViewTextBoxColumn.Name = "apellidoDataGridViewTextBoxColumn";
            this.apellidoDataGridViewTextBoxColumn.Width = 125;
            // 
            // fechaNacimientoDataGridViewTextBoxColumn
            // 
            this.fechaNacimientoDataGridViewTextBoxColumn.DataPropertyName = "FechaNacimiento";
            this.fechaNacimientoDataGridViewTextBoxColumn.HeaderText = "FechaNacimiento";
            this.fechaNacimientoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.fechaNacimientoDataGridViewTextBoxColumn.Name = "fechaNacimientoDataGridViewTextBoxColumn";
            this.fechaNacimientoDataGridViewTextBoxColumn.Width = 125;
            // 
            // tiempoCarreraDataGridViewTextBoxColumn
            // 
            this.tiempoCarreraDataGridViewTextBoxColumn.DataPropertyName = "TiempoCarrera";
            this.tiempoCarreraDataGridViewTextBoxColumn.HeaderText = "TiempoCarrera";
            this.tiempoCarreraDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tiempoCarreraDataGridViewTextBoxColumn.Name = "tiempoCarreraDataGridViewTextBoxColumn";
            this.tiempoCarreraDataGridViewTextBoxColumn.Width = 125;
            // 
            // dNIDataGridViewTextBoxColumn
            // 
            this.dNIDataGridViewTextBoxColumn.DataPropertyName = "DNI";
            this.dNIDataGridViewTextBoxColumn.HeaderText = "DNI";
            this.dNIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dNIDataGridViewTextBoxColumn.Name = "dNIDataGridViewTextBoxColumn";
            this.dNIDataGridViewTextBoxColumn.Width = 125;
            // 
            // sexoDataGridViewTextBoxColumn
            // 
            this.sexoDataGridViewTextBoxColumn.DataPropertyName = "Sexo";
            this.sexoDataGridViewTextBoxColumn.HeaderText = "Sexo";
            this.sexoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sexoDataGridViewTextBoxColumn.Name = "sexoDataGridViewTextBoxColumn";
            this.sexoDataGridViewTextBoxColumn.Width = 125;
            // 
            // tallaDeCamisaDataGridViewTextBoxColumn
            // 
            this.tallaDeCamisaDataGridViewTextBoxColumn.DataPropertyName = "TallaDeCamisa";
            this.tallaDeCamisaDataGridViewTextBoxColumn.HeaderText = "TallaDeCamisa";
            this.tallaDeCamisaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tallaDeCamisaDataGridViewTextBoxColumn.Name = "tallaDeCamisaDataGridViewTextBoxColumn";
            this.tallaDeCamisaDataGridViewTextBoxColumn.Width = 125;
            // 
            // nombreCamisetaDataGridViewTextBoxColumn
            // 
            this.nombreCamisetaDataGridViewTextBoxColumn.DataPropertyName = "NombreCamiseta";
            this.nombreCamisetaDataGridViewTextBoxColumn.HeaderText = "NombreCamiseta";
            this.nombreCamisetaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nombreCamisetaDataGridViewTextBoxColumn.Name = "nombreCamisetaDataGridViewTextBoxColumn";
            this.nombreCamisetaDataGridViewTextBoxColumn.Width = 125;
            // 
            // insripcionSolidariaDataGridViewCheckBoxColumn
            // 
            this.insripcionSolidariaDataGridViewCheckBoxColumn.DataPropertyName = "InsripcionSolidaria";
            this.insripcionSolidariaDataGridViewCheckBoxColumn.HeaderText = "InsripcionSolidaria";
            this.insripcionSolidariaDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.insripcionSolidariaDataGridViewCheckBoxColumn.Name = "insripcionSolidariaDataGridViewCheckBoxColumn";
            this.insripcionSolidariaDataGridViewCheckBoxColumn.Width = 125;
            // 
            // recibirNoticiasDataGridViewCheckBoxColumn
            // 
            this.recibirNoticiasDataGridViewCheckBoxColumn.DataPropertyName = "RecibirNoticias";
            this.recibirNoticiasDataGridViewCheckBoxColumn.HeaderText = "RecibirNoticias";
            this.recibirNoticiasDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.recibirNoticiasDataGridViewCheckBoxColumn.Name = "recibirNoticiasDataGridViewCheckBoxColumn";
            this.recibirNoticiasDataGridViewCheckBoxColumn.Width = 125;
            // 
            // atletismoBindingSource1
            // 
            this.atletismoBindingSource1.DataMember = "Atletismo";
            this.atletismoBindingSource1.DataSource = this.atletasDataSet;
            // 
            // atletasDataSet
            // 
            this.atletasDataSet.DataSetName = "AtletasDataSet";
            this.atletasDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // atletismoBindingSource
            // 
            this.atletismoBindingSource.DataMember = "Atletismo";
            this.atletismoBindingSource.DataSource = this.atletasDataSet;
            // 
            // atletismoTableAdapter
            // 
            this.atletismoTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AtletismoTableAdapter = this.atletismoTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = CarreraV3.AtletasDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // nombreTextBox
            // 
            this.nombreTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.atletismoBindingSource, "Nombre", true));
            this.nombreTextBox.Location = new System.Drawing.Point(225, 46);
            this.nombreTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nombreTextBox.Name = "nombreTextBox";
            this.nombreTextBox.Size = new System.Drawing.Size(200, 22);
            this.nombreTextBox.TabIndex = 24;
            // 
            // apellidoTextBox
            // 
            this.apellidoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.atletismoBindingSource, "Apellido", true));
            this.apellidoTextBox.Location = new System.Drawing.Point(225, 84);
            this.apellidoTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apellidoTextBox.Name = "apellidoTextBox";
            this.apellidoTextBox.Size = new System.Drawing.Size(200, 22);
            this.apellidoTextBox.TabIndex = 25;
            // 
            // fechaNacimientoDateTimePicker
            // 
            this.fechaNacimientoDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.atletismoBindingSource, "FechaNacimiento", true));
            this.fechaNacimientoDateTimePicker.Location = new System.Drawing.Point(225, 122);
            this.fechaNacimientoDateTimePicker.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fechaNacimientoDateTimePicker.Name = "fechaNacimientoDateTimePicker";
            this.fechaNacimientoDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.fechaNacimientoDateTimePicker.TabIndex = 26;
            // 
            // tiempoCarreraTextBox
            // 
            this.tiempoCarreraTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.atletismoBindingSource, "TiempoCarrera", true));
            this.tiempoCarreraTextBox.Location = new System.Drawing.Point(225, 155);
            this.tiempoCarreraTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tiempoCarreraTextBox.Name = "tiempoCarreraTextBox";
            this.tiempoCarreraTextBox.Size = new System.Drawing.Size(200, 22);
            this.tiempoCarreraTextBox.TabIndex = 27;
            // 
            // dNITextBox
            // 
            this.dNITextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.atletismoBindingSource, "DNI", true));
            this.dNITextBox.Location = new System.Drawing.Point(225, 191);
            this.dNITextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dNITextBox.Name = "dNITextBox";
            this.dNITextBox.Size = new System.Drawing.Size(200, 22);
            this.dNITextBox.TabIndex = 28;
            // 
            // nombreCamisetaTextBox
            // 
            this.nombreCamisetaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.atletismoBindingSource, "NombreCamiseta", true));
            this.nombreCamisetaTextBox.Location = new System.Drawing.Point(756, 118);
            this.nombreCamisetaTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nombreCamisetaTextBox.Name = "nombreCamisetaTextBox";
            this.nombreCamisetaTextBox.Size = new System.Drawing.Size(200, 22);
            this.nombreCamisetaTextBox.TabIndex = 31;
            // 
            // insripcionSolidariaCheckBox
            // 
            this.insripcionSolidariaCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.atletismoBindingSource, "InsripcionSolidaria", true));
            this.insripcionSolidariaCheckBox.Location = new System.Drawing.Point(756, 155);
            this.insripcionSolidariaCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.insripcionSolidariaCheckBox.Name = "insripcionSolidariaCheckBox";
            this.insripcionSolidariaCheckBox.Size = new System.Drawing.Size(104, 25);
            this.insripcionSolidariaCheckBox.TabIndex = 32;
            this.insripcionSolidariaCheckBox.Text = "checkBox1";
            this.insripcionSolidariaCheckBox.UseVisualStyleBackColor = true;
            // 
            // recibirNoticiasCheckBox
            // 
            this.recibirNoticiasCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.atletismoBindingSource, "RecibirNoticias", true));
            this.recibirNoticiasCheckBox.Location = new System.Drawing.Point(756, 191);
            this.recibirNoticiasCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.recibirNoticiasCheckBox.Name = "recibirNoticiasCheckBox";
            this.recibirNoticiasCheckBox.Size = new System.Drawing.Size(104, 25);
            this.recibirNoticiasCheckBox.TabIndex = 33;
            this.recibirNoticiasCheckBox.Text = "checkBox1";
            this.recibirNoticiasCheckBox.UseVisualStyleBackColor = true;
            // 
            // Seleccion
            // 
            this.Seleccion.AllowDrop = true;
            this.Seleccion.AutoCompleteCustomSource.AddRange(new string[] {
            "participantes",
            "sexo",
            "edad",
            "camiseta",
            "carrera"});
            this.Seleccion.FormattingEnabled = true;
            this.Seleccion.Location = new System.Drawing.Point(609, 322);
            this.Seleccion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Seleccion.Name = "Seleccion";
            this.Seleccion.Size = new System.Drawing.Size(195, 24);
            this.Seleccion.TabIndex = 34;
            this.Seleccion.SelectedIndexChanged += new System.EventHandler(this.Seleccion_SelectedIndexChanged);
            // 
            // btnVer
            // 
            this.btnVer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnVer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnVer.Location = new System.Drawing.Point(709, 356);
            this.btnVer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVer.Name = "btnVer";
            this.btnVer.Size = new System.Drawing.Size(197, 37);
            this.btnVer.TabIndex = 35;
            this.btnVer.Text = "Buscar";
            this.btnVer.UseVisualStyleBackColor = false;
            this.btnVer.Click += new System.EventHandler(this.btnVer_Click);
            // 
            // seleccion2
            // 
            this.seleccion2.FormattingEnabled = true;
            this.seleccion2.Location = new System.Drawing.Point(812, 322);
            this.seleccion2.Margin = new System.Windows.Forms.Padding(4);
            this.seleccion2.Name = "seleccion2";
            this.seleccion2.Size = new System.Drawing.Size(195, 24);
            this.seleccion2.TabIndex = 36;
            // 
            // Eliminar
            // 
            this.Eliminar.BackColor = System.Drawing.Color.Firebrick;
            this.Eliminar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Eliminar.Location = new System.Drawing.Point(44, 335);
            this.Eliminar.Margin = new System.Windows.Forms.Padding(4);
            this.Eliminar.Name = "Eliminar";
            this.Eliminar.Size = new System.Drawing.Size(200, 59);
            this.Eliminar.TabIndex = 37;
            this.Eliminar.Text = "Eliminar Usuario";
            this.Eliminar.UseVisualStyleBackColor = false;
            this.Eliminar.Click += new System.EventHandler(this.Eliminar_Click);
            // 
            // comboSexo
            // 
            this.comboSexo.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.atletismoBindingSource, "Sexo", true));
            this.comboSexo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.atletismoBindingSource, "Sexo", true));
            this.comboSexo.FormattingEnabled = true;
            this.comboSexo.Location = new System.Drawing.Point(756, 42);
            this.comboSexo.Margin = new System.Windows.Forms.Padding(4);
            this.comboSexo.Name = "comboSexo";
            this.comboSexo.Size = new System.Drawing.Size(200, 24);
            this.comboSexo.TabIndex = 38;
            // 
            // comboTallaCamisa
            // 
            this.comboTallaCamisa.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.atletismoBindingSource, "TallaDeCamisa", true));
            this.comboTallaCamisa.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.atletismoBindingSource, "TallaDeCamisa", true));
            this.comboTallaCamisa.FormattingEnabled = true;
            this.comboTallaCamisa.Location = new System.Drawing.Point(756, 80);
            this.comboTallaCamisa.Margin = new System.Windows.Forms.Padding(4);
            this.comboTallaCamisa.Name = "comboTallaCamisa";
            this.comboTallaCamisa.Size = new System.Drawing.Size(200, 24);
            this.comboTallaCamisa.TabIndex = 39;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(619, 292);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 17);
            this.label2.TabIndex = 42;
            this.label2.Text = "Busqueda Por :";
            // 
            // editarDatoss
            // 
            this.editarDatoss.BackColor = System.Drawing.Color.Goldenrod;
            this.editarDatoss.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.editarDatoss.Location = new System.Drawing.Point(248, 334);
            this.editarDatoss.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.editarDatoss.Name = "editarDatoss";
            this.editarDatoss.Size = new System.Drawing.Size(200, 60);
            this.editarDatoss.TabIndex = 43;
            this.editarDatoss.Text = "Editar Usuario";
            this.editarDatoss.UseVisualStyleBackColor = false;
            this.editarDatoss.Click += new System.EventHandler(this.editarDatoss_Click);
            // 
            // btnNuevoUsuario
            // 
            this.btnNuevoUsuario.BackColor = System.Drawing.Color.SteelBlue;
            this.btnNuevoUsuario.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnNuevoUsuario.Location = new System.Drawing.Point(43, 268);
            this.btnNuevoUsuario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNuevoUsuario.Name = "btnNuevoUsuario";
            this.btnNuevoUsuario.Size = new System.Drawing.Size(200, 60);
            this.btnNuevoUsuario.TabIndex = 44;
            this.btnNuevoUsuario.Text = "Nuevo Usuario";
            this.btnNuevoUsuario.UseVisualStyleBackColor = false;
            this.btnNuevoUsuario.Click += new System.EventHandler(this.btnNuevoUsuario_Click);
            // 
            // atletismoDataGridView
            // 
            this.atletismoDataGridView.AutoGenerateColumns = false;
            this.atletismoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.atletismoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewCheckBoxColumn2});
            this.atletismoDataGridView.DataSource = this.atletismoBindingSource;
            this.atletismoDataGridView.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.atletismoDataGridView.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.atletismoDataGridView.Location = new System.Drawing.Point(33, 396);
            this.atletismoDataGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.atletismoDataGridView.Name = "atletismoDataGridView";
            this.atletismoDataGridView.RowHeadersWidth = 51;
            this.atletismoDataGridView.RowTemplate.Height = 24;
            this.atletismoDataGridView.Size = new System.Drawing.Size(975, 204);
            this.atletismoDataGridView.TabIndex = 44;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Nombre";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nombre";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Apellido";
            this.dataGridViewTextBoxColumn3.HeaderText = "Apellido";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "FechaNacimiento";
            this.dataGridViewTextBoxColumn4.HeaderText = "FechaNacimiento";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "TiempoCarrera";
            this.dataGridViewTextBoxColumn5.HeaderText = "TiempoCarrera";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "DNI";
            this.dataGridViewTextBoxColumn6.HeaderText = "DNI";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Sexo";
            this.dataGridViewTextBoxColumn7.HeaderText = "Sexo";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "TallaDeCamisa";
            this.dataGridViewTextBoxColumn8.HeaderText = "TallaDeCamisa";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 125;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "NombreCamiseta";
            this.dataGridViewTextBoxColumn9.HeaderText = "NombreCamiseta";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 125;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "InsripcionSolidaria";
            this.dataGridViewCheckBoxColumn1.HeaderText = "InsripcionSolidaria";
            this.dataGridViewCheckBoxColumn1.MinimumWidth = 6;
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.Width = 125;
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.DataPropertyName = "RecibirNoticias";
            this.dataGridViewCheckBoxColumn2.HeaderText = "RecibirNoticias";
            this.dataGridViewCheckBoxColumn2.MinimumWidth = 6;
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.Width = 125;
            // 
            // Patrocinadores
            // 
            this.Patrocinadores.BackColor = System.Drawing.Color.OrangeRed;
            this.Patrocinadores.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Patrocinadores.Location = new System.Drawing.Point(225, 223);
            this.Patrocinadores.Name = "Patrocinadores";
            this.Patrocinadores.Size = new System.Drawing.Size(126, 45);
            this.Patrocinadores.TabIndex = 45;
            this.Patrocinadores.Text = "Patrocinadores";
            this.Patrocinadores.UseVisualStyleBackColor = false;
            this.Patrocinadores.Click += new System.EventHandler(this.Patrocinadores_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 17);
            this.label1.TabIndex = 46;
            this.label1.Text = "Añadir Patrocinadores";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1041, 614);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Patrocinadores);
            this.Controls.Add(this.atletismoDataGridView);
            this.Controls.Add(this.btnNuevoUsuario);
            this.Controls.Add(this.editarDatoss);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboTallaCamisa);
            this.Controls.Add(this.comboSexo);
            this.Controls.Add(this.Eliminar);
            this.Controls.Add(this.seleccion2);
            this.Controls.Add(this.btnVer);
            this.Controls.Add(this.Seleccion);
            this.Controls.Add(recibirNoticiasLabel);
            this.Controls.Add(this.recibirNoticiasCheckBox);
            this.Controls.Add(insripcionSolidariaLabel);
            this.Controls.Add(this.insripcionSolidariaCheckBox);
            this.Controls.Add(nombreCamisetaLabel);
            this.Controls.Add(this.nombreCamisetaTextBox);
            this.Controls.Add(tallaDeCamisaLabel);
            this.Controls.Add(sexoLabel);
            this.Controls.Add(dNILabel);
            this.Controls.Add(this.dNITextBox);
            this.Controls.Add(tiempoCarreraLabel);
            this.Controls.Add(this.tiempoCarreraTextBox);
            this.Controls.Add(fechaNacimientoLabel);
            this.Controls.Add(this.fechaNacimientoDateTimePicker);
            this.Controls.Add(apellidoLabel);
            this.Controls.Add(this.apellidoTextBox);
            this.Controls.Add(nombreLabel);
            this.Controls.Add(this.nombreTextBox);
            this.Controls.Add(this.Guardar);
            this.Controls.Add(this.CarreraDataGreed);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CarreraDataGreed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.atletismoBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.atletasDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.atletismoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.atletismoDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Guardar;
        private System.Windows.Forms.DataGridView CarreraDataGreed;
        private AtletasDataSet atletasDataSet;
        private System.Windows.Forms.BindingSource atletismoBindingSource;
        private AtletasDataSetTableAdapters.AtletismoTableAdapter atletismoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellidoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaNacimientoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tiempoCarreraDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dNIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sexoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tallaDeCamisaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreCamisetaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn insripcionSolidariaDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn recibirNoticiasDataGridViewCheckBoxColumn;
        private AtletasDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox nombreTextBox;
        private System.Windows.Forms.TextBox apellidoTextBox;
        private System.Windows.Forms.DateTimePicker fechaNacimientoDateTimePicker;
        private System.Windows.Forms.TextBox tiempoCarreraTextBox;
        private System.Windows.Forms.TextBox dNITextBox;
        private System.Windows.Forms.TextBox nombreCamisetaTextBox;
        private System.Windows.Forms.CheckBox insripcionSolidariaCheckBox;
        private System.Windows.Forms.CheckBox recibirNoticiasCheckBox;
        private System.Windows.Forms.ComboBox Seleccion;
        private System.Windows.Forms.Button btnVer;
        private System.Windows.Forms.ComboBox seleccion2;
        private System.Windows.Forms.Button Eliminar;
        private System.Windows.Forms.ComboBox comboSexo;
        private System.Windows.Forms.ComboBox comboTallaCamisa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button editarDatoss;
        private System.Windows.Forms.BindingSource atletismoBindingSource1;
        private System.Windows.Forms.Button btnNuevoUsuario;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridView atletismoDataGridView;
        private System.Windows.Forms.Button Patrocinadores;
        private System.Windows.Forms.Label label1;
    }
}

