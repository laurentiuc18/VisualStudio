﻿namespace CarreraV3
{
    public class boolean
    {
    }
}