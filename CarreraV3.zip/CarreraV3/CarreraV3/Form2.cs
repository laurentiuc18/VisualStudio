﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarreraV3
{
    
    public partial class Form2 : Form
    {
        Boolean edicion = true;
        Boolean editado = false;
        OleDbConnection conexion = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\Patrocinadores2.accdb");
        public Form2()
        {
            InitializeComponent();

            seleccionBusqueda.Items.Add("Todos");
            seleccionBusqueda.Items.Add("aportacion economica");
            seleccionBusqueda.Items.Add("aportacion material");
            seleccionBusqueda.Items.Add("aportacion premios");
            seleccionBusqueda.Text = "Todos";


            comboTipoPatrocinio.Items.Add("aportacion economica");
            comboTipoPatrocinio.Items.Add("aportacion material");
            comboTipoPatrocinio.Items.Add("aportacion premios");


            nombreTextBox.Enabled = false;
            cantidadDineroTextBox.Enabled = false;
            fechaInicioDateTimePicker.Enabled = false;
            comboTipoPatrocinio.Enabled = false;
        }

        private void patrocinadoresBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.patrocinadoresBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.patrocinadores2DataSet);

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'patrocinadores2DataSet.patrocinadores' Puede moverla o quitarla según sea necesario.
            this.patrocinadoresTableAdapter.Fill(this.patrocinadores2DataSet.patrocinadores);

        }

        private void btnNuevoPatrocinadores_Click(object sender, EventArgs e)
        {
            if (btnNuevoPatrocinadores.Text == "Nuevo Patrocinador" && editado == true)
            {




                nombreTextBox.Text = "";
                nombreTextBox.Text = "";
                cantidadDineroTextBox.Text = "";


                Eliminar.Enabled = false;
                Eliminar.Visible = false;
                editarDatoss.Enabled = false;
                editarDatoss.Visible = false;
                btnNuevoPatrocinadores.Text = "Cancelar";
                btnNuevoPatrocinadores.BackColor = Color.Firebrick;
              
            }
            else if (btnNuevoPatrocinadores.Text == "Nuevo Patrocinador" && editado == false) 
            
            { MessageBox.Show("La edicion no esta activa"); }
            else
            {


                

                Eliminar.Enabled = true;
                Eliminar.Visible = true;
                editarDatoss.Enabled = true;
                editarDatoss.Visible = true;
                btnNuevoPatrocinadores.Text = "Nuevo Patrocinador";
                btnNuevoPatrocinadores.BackColor = Color.SteelBlue;
                editado = false;

            }
        }

        public void LlamarTodosDatosBDO(String datos)
        {

            conexion.Open();
            OleDbCommand cmd = conexion.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = datos;


            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();

            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            patrocinadoresDataGridView.DataSource = dt;
            conexion.Close();
            this.patrocinadoresTableAdapter.Fill(this.patrocinadores2DataSet.patrocinadores);
        }

        public void Ver()
        {

            String Filtro = "";

            switch (seleccionBusqueda.SelectedItem)
            {
                case "Todos":
                    Filtro = "SELECT * FROM patrocinadores";
                    break;
                case "aportacion economica":
                    Filtro = "SELECT * FROM patrocinadores WHERE tipoPatrocinio='aportacion economica'";
                    break;
                case "aportacion material":
                    Filtro = "SELECT * FROM patrocinadores WHERE tipoPatrocinio='aportacion material'";
                    break;
                case "aportacion premios":
                    Filtro = "SELECT * FROM patrocinadores WHERE tipoPatrocinio='aportacion premios'";
                    break;
                default:

                    MessageBox.Show("Seleccione alguna opcion en el desplegable");
                    Filtro = "SELECT * FROM patrocinadores";
                    break;
            }

            LlamarTodosDatosBDO(Filtro);

        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            Ver();
        }

        private void Guardar_Click(object sender, EventArgs e)
        {

            if (editado == true)
            {

                String Cambiar;
                Cambiar = "insert into patrocinadores(Nombre,CantidadDinero,FechaInicio, tipoPatrocinio) " +
                      "values('" + nombreTextBox.Text + "', '" + cantidadDineroTextBox.Text + "', '" + fechaInicioDateTimePicker.Value + "', '" + comboTipoPatrocinio.SelectedItem + "')";

                LlamarTodosDatosBDO(Cambiar);

                Ver();


                nombreTextBox.Enabled = false;
                cantidadDineroTextBox.Enabled = false;
                fechaInicioDateTimePicker.Enabled = false;
                comboTipoPatrocinio.Enabled = false;

                Eliminar.Enabled = true;
                Eliminar.Visible = true;
                editarDatoss.Enabled = true;
                editarDatoss.Visible = true;
                btnNuevoPatrocinadores.Text = "Nuevo Patrocinador";
                btnNuevoPatrocinadores.BackColor = Color.SteelBlue;
            }
            else { MessageBox.Show("La edicion no esta activa"); }
        }
        public int SeleccionarDataGreed()
        {
            int idSeleccionada = (int)patrocinadoresDataGridView.Rows[patrocinadoresDataGridView.CurrentRow.Index].Cells[0].Value;
            return idSeleccionada;
        }
        private void Eliminar_Click(object sender, EventArgs e)
        {
            if (patrocinadoresDataGridView.CurrentRow != null && editado==true)
            {

                String datos = "DELETE FROM patrocinadores WHERE Id=" + SeleccionarDataGreed();//Para eliminar un usuario
                LlamarTodosDatosBDO(datos);


                MessageBox.Show("Corredor eliminado correctamente");
                Ver();
            }
            else { MessageBox.Show("Porfavor seleccione el usuario que desea eliminar o active la edicion"); }
        }

        private void editarDatoss_Click(object sender, EventArgs e)
        {
            if (editado == true) {
                String Cambiar;


                Cambiar = "UPDATE patrocinadores SET Nombre='" + nombreTextBox.Text + "',CantidadDinero='" + cantidadDineroTextBox.Text + "',FechaInicio='" + fechaInicioDateTimePicker.Value +
             "',tipoPatrocinio='" + comboTipoPatrocinio.SelectedItem + "'" + " WHERE id like '" + SeleccionarDataGreed() + "'";




                LlamarTodosDatosBDO(Cambiar);

                Ver();
                MessageBox.Show("PARTICIPANTE EDITADO CORRECTAMENTE");
                    }
            else { MessageBox.Show("Active la edicion"); }
        }

        private void Edicion_Click(object sender, EventArgs e)
        {
            if (edicion == true)
            {

                nombreTextBox.Enabled = true;
                cantidadDineroTextBox.Enabled = true;
                fechaInicioDateTimePicker.Enabled = true;
                comboTipoPatrocinio.Enabled = true;
                edicion = false;
                editado = true;
            }
            else {


                nombreTextBox.Enabled = false;
                cantidadDineroTextBox.Enabled = false;
                fechaInicioDateTimePicker.Enabled = false;
                comboTipoPatrocinio.Enabled = false;
                edicion = true;
                editado = false;
            }
        }
    }
}
