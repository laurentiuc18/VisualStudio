﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarreraV3
{
    public partial class Form1 : Form
    {

        OleDbConnection conexion = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\Atletas.accdb");

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'atletasDataSet.Atletismo' Puede moverla o quitarla según sea necesario.
          //  this.atletismoTableAdapter.Fill(this.atletasDataSet.Atletismo);

            //Cargar Combobox
            
            Seleccion.Items.Add("Todos los participantes");
            Seleccion.Items.Add("Participantes por sexo");
            Seleccion.Items.Add("Participantes por camiseta");
            Seleccion.Items.Add("Participantes por carrera");
            Seleccion.Text = "Todos los participantes";

            



        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            //Guardar nuevo usuario
         if (CalculoLetraDNI()) {

                String Cambiar;
                String nombre = nombreTextBox.Text;
                
                String apellido = apellidoTextBox.Text;


                if (CampoVacio(nombre) && CampoVacio(apellido))
                {
                    nombreTextBox.Text = EditarMayusculas(nombre);
                    apellidoTextBox.Text = EditarMayusculas(apellido);

                    //Por Alguna razon agrega 2 usuarios iguales
                    Cambiar = "insert into Atletismo(Nombre,Apellido,FechaNacimiento, TiempoCarrera, DNI,Sexo,TallaDeCamisa,NombreCamiseta,InsripcionSolidaria,RecibirNoticias) " +
                   "values('" + nombreTextBox.Text + "', '" + apellidoTextBox.Text + "', '" + fechaNacimientoDateTimePicker.Value +
                   "', '" + tiempoCarreraTextBox.Text + "', '" + dNITextBox.Text + "', '" + comboSexo.SelectedItem + "', '" + comboTallaCamisa.SelectedItem + "', '" + nombreCamisetaTextBox.Text + "'" +
                 ", '" + ((insripcionSolidariaCheckBox.Checked) ? 1 : 0) + "', '" + ((recibirNoticiasCheckBox.Checked) ? 1 : 0) + "')";

                    LlamarTodosDatosBDO(Cambiar);

                    Ver();

                    Eliminar.Enabled = true;
                    Eliminar.Visible = true;
                    editarDatoss.Enabled = true;
                    editarDatoss.Visible = true;
                    btnNuevoUsuario.Text = "Nuevo Usuario";
                    btnNuevoUsuario.BackColor = Color.SteelBlue;
                    MessageBox.Show("Concursante añadido correctamente");

                }
                else { MessageBox.Show("Nombre o Apellido Vacio"); Ver(); }
            }
            
           else { MessageBox.Show("DNI no es correcto"); }
        }
        private void btnVer_Click(object sender, EventArgs e)
        {
            Ver();
           
        }
        //Filtro base de datos
             public void Ver() {

            String Filtro="";
            
            switch (seleccion2.SelectedItem)
            {
                case "Todos":
                    Filtro = "";
                    break;
                case "Mujeres":
                    Filtro = "Sexo='F'";
                    break;
                case "Hombres":
                    Filtro = "Sexo='M'";
                    break;
                case "S":
                    Filtro = "TallaDeCamisa='S'";
                    break;
                case "M":
                    Filtro = "TallaDeCamisa='M'";
                    break;
                case "L":
                    Filtro = "TallaDeCamisa='L'";
                    break;
                case "XL":
                    Filtro = "TallaDeCamisa='XL'";
                    break;
                case "Menos de 30 Min":
                    Filtro = "TiempoCarrera<=30";
                    break;
                case "Mas de 30 Min":
                    Filtro = "TiempoCarrera>=30";
                    break;
                default:

                    MessageBox.Show("Seleccione alguna opcion en el desplegable");

                 

                    break;
            }
            //Filtrar el bindings

            atletismoBindingSource.Filter = Filtro;



        }
       
            public void LlamarTodosDatosBDO(String datos) {
           
            conexion.Open();
            OleDbCommand cmd = conexion.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = datos;

           
            cmd.ExecuteNonQuery();
            
            DataTable dt = new DataTable();

            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            CarreraDataGreed.DataSource = dt;
            conexion.Close();
            this.atletismoTableAdapter.Fill(this.atletasDataSet.Atletismo);
        }


        //Es el 1r Combobox, actualiza al segundo combobox
        private void Seleccion_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (Seleccion.SelectedIndex)
            {
                case 0:
                    seleccion2.Items.Clear();
                    seleccion2.Items.Add("Todos");
                    seleccion2.Text = "Todos";
                    break;
                case 1:
                    seleccion2.Items.Clear();
                    seleccion2.Items.Add("Mujeres");
                    seleccion2.Items.Add("Hombres");
                    seleccion2.Text = "Mujeres";
                    break;
                case 2:
                    
                    seleccion2.Items.Clear();
                    seleccion2.Items.Add("S");
                    seleccion2.Items.Add("M");
                    seleccion2.Items.Add("L");
                    seleccion2.Items.Add("XL");
                    seleccion2.Text = "S";
                    break;
                case 3:

                    seleccion2.Items.Clear();
                    seleccion2.Items.Add("Menos de 30 Min");
                    seleccion2.Items.Add("Mas de 30 Min");
                    seleccion2.Text = "Menos de 30 Min";

                    break;
                
                default:
                    MessageBox.Show("Seleccione alguna opcion en el desplegable");
                    break;
            }
            }
        //Boton eliminar
        private void Eliminar_Click(object sender, EventArgs e)
        {

            if (atletismoDataGridView.CurrentRow != null) {

                String datos = "DELETE FROM Atletismo WHERE Id=" + SeleccionarDataGreed();//Para eliminar un usuario
                LlamarTodosDatosBDO(datos);

               
                MessageBox.Show("Corredor eliminado correctamente");
                Ver();
        }else{ MessageBox.Show("Porfavor seleccione el usuario que desea eliminar"); }
            
        }

        //Calcular la letra del dni para comprobar si el dni es correcto
        public Boolean CalculoLetraDNI() {

            string[] letras = { "T", "R", "W", "A", "G", "M", "Y", "F", "P", "D", "X", "B", "N", "J", "Z", "S", "Q", "V", "H", "L", "C", "K", "E"};

            int numero;
            String letra;
            String letraCalculo;
            if (dNITextBox.TextLength == 9){

                letra = dNITextBox.Text.Substring(8).ToUpper();
                numero = int.Parse(dNITextBox.Text.Substring(0, 8));

                letraCalculo = letras[numero % 23];

                if (letraCalculo == letra) { return true; 
                
                }
                else { return false; }
            }

            else { return false; }
           
        }

        //Buscar La id de la linea seleccionada en caso necessario implementar en cualquier lugar
        public int SeleccionarDataGreed() {
            int idSeleccionada = (int)atletismoDataGridView.Rows[atletismoDataGridView.CurrentRow.Index].Cells[0].Value;
            return idSeleccionada;
        }

        //Boton Editar
        private void editarDatoss_Click(object sender, EventArgs e)
        {



            if (CarreraDataGreed.CurrentRow != null)
            {
                String Cambiar;
                String nombre = nombreTextBox.Text;
                String apellido = apellidoTextBox.Text;

                if (CampoVacio(nombre) && CampoVacio(apellido))
                {

                    nombreTextBox.Text = EditarMayusculas(nombre);

                    apellidoTextBox.Text = EditarMayusculas(apellido);

                    //Editar campo selecccionado(Funciona raro)
                    Cambiar = "UPDATE Atletismo SET Nombre='" + nombreTextBox.Text + "',Apellido='" + apellidoTextBox.Text + "',FechaNacimiento='" + fechaNacimientoDateTimePicker.Value +
                       "',TiempoCarrera='" + tiempoCarreraTextBox.Text + "',DNI='" + dNITextBox.Text + "',Sexo='" + comboSexo.SelectedItem + "',TallaDeCamisa='" + comboTallaCamisa.SelectedItem + "',NombreCamiseta='" + nombreCamisetaTextBox.Text + "',InsripcionSolidaria='"
                       + ((insripcionSolidariaCheckBox.Checked) ? 1 : 0) + "',RecibirNoticias='" + ((recibirNoticiasCheckBox.Checked) ? 1 : 0) + "'" + " WHERE id like '" + SeleccionarDataGreed() + "'";




                    LlamarTodosDatosBDO(Cambiar);

                    Ver();
                    MessageBox.Show("PARTICIPANTE EDITADO CORRECTAMENTE");
                }
                else {  MessageBox.Show("Nombre o Apellido Vacio");Ver(); }



              

            } 

        }

        //Convertir nombre en mayuscula y minuscula
        private String EditarMayusculas(String palabra) {


            String LetraMayuscula = palabra;
            String RestosPalabra = palabra;
            String Resultado;


            LetraMayuscula = palabra.Substring(0, 1).ToUpper();
            RestosPalabra = palabra.Substring(1).ToLower();
            
            Resultado = LetraMayuscula + RestosPalabra;

            return Resultado;


        }


        private Boolean CampoVacio(string Campo) {

            Boolean hayPalabra=true;
            if (Campo.Equals("")) { hayPalabra = false; }
            
            return hayPalabra; }

        //Boton crear nuevo usuario
        private void btnNuevoUsuario_Click(object sender, EventArgs e)
        {
            //Poner campos en blanco
            if (btnNuevoUsuario.Text == "Nuevo Usuario")
            {
                nombreTextBox.Text = "";
                apellidoTextBox.Text = "";
                tiempoCarreraTextBox.Text = "";
                dNITextBox.Text = "";
                nombreCamisetaTextBox.Text = "";
                insripcionSolidariaCheckBox.Checked = false;
                recibirNoticiasCheckBox.Checked = false;

                Eliminar.Enabled = false;
                Eliminar.Visible = false;
                editarDatoss.Enabled = false;
                editarDatoss.Visible = false;
                btnNuevoUsuario.Text = "Cancelar";
                btnNuevoUsuario.BackColor = Color.Firebrick;
            }
            else {
                Eliminar.Enabled = true;
                Eliminar.Visible = true;
                editarDatoss.Enabled = true;
                editarDatoss.Visible = true;
                btnNuevoUsuario.Text = "Nuevo Usuario";
                btnNuevoUsuario.BackColor = Color.SteelBlue;
                
            }
        }

        private void Patrocinadores_Click(object sender, EventArgs e)
        {
            Form2 ventana = new Form2();

            ventana.Show();
            
        }
    }
}
