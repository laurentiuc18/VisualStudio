﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Litros_agua
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void CampoTexto_TextChanged(object sender, EventArgs e)
        {



        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
                Double numero = double.Parse(CampoTexto.Text);



            if (numero < 0)
            {
                Vista.Text = "Ingresa numeros mayores a 0";
            }
            else if (numero >= 1 && numero <= 50)
            {
                Vista.Text = "20 €";
            }
            else if (numero >= 50 && numero <= 200)
            {
                Vista.Text = (20 + ((numero - 50) * 0.20)) + "€";
            }
            else if (numero >200) {

                Vista.Text = (50 + ((numero - 200) * 0.10)) + "€"; }


            


            
        }
    }
}
