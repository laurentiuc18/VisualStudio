﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace Desepertador
{
    public partial class Form1 : Form
    {
        
        static System.Windows.Forms.Timer myTimer = new System.Windows.Forms.Timer();
      
        SoundPlayer player = new SoundPlayer();
        OleDbConnection conexion = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\Despertador.accdb");
       
        public Form1()
        {
            InitializeComponent();


            this.BackColor = Color.WhiteSmoke;
        }

    

        private void Temporizador(object sender, EventArgs e)
        {

            if (activoCheckBox.Checked)
            {

                alarma();
            }

            String hora = DateTime.Now.ToLongTimeString();

            progressBar1.Value = DateTime.Now.Second;
            label1.Text = DateTime.Now.ToString(hora+" "+"tt");
            
            label2.Text = DateTime.Now.ToString("dddd, dd, MMMM, yyyy");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'despertadorDataSet.Horas' Puede moverla o quitarla según sea necesario.
            this.horasTableAdapter.Fill(this.despertadorDataSet.Horas);

            myTimer.Interval = 1000;
            myTimer.Tick += T_Tick;
        }

        private void T_Tick(object sender, EventArgs e)
        {
            DateTime currentTime = DateTime.Now;

            DateTime userTimer = fechaDateTimePicker.Value;



            if (currentTime.Hour == userTimer.Hour && currentTime.Minute == userTimer.Minute && currentTime.Second == userTimer.Second)
            {


                myTimer.Stop();

                //label3.Text = "Stop";

                try
                {

                    SoundPlayer player = new SoundPlayer();
                    player.SoundLocation = @"C:\Windows\Media\Alarm01.wav";
                    player.PlayLooping();
                    this.BackColor = Color.Blue;
                    
                }
                catch (Exception ex)
                {


                    MessageBox.Show(ex.Message, "Error alarma", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void Start_Click(object sender, EventArgs e)
        {
            alarma();
           
        }


        public void cambiar()
        {
            activoCheckBox.Checked = true;
        }
            public void alarma() {

            myTimer.Start();
            
            activoCheckBox.Checked = true;
            label5.Text = "Started...";
          
        }


        private void Guardar() {
          
            String Cambiar;
        
                            Cambiar = "UPDATE Horas SET Fecha='" + fechaDateTimePicker.Value + "',Activo='" + ((activoCheckBox.Checked) ? 1 : 0) + "'" + " WHERE id like '" + 1 + "'";

            GuardarDatos.Guardar(Cambiar);

        }

        private void Stop_Click(object sender, EventArgs e)
        {
            myTimer.Stop();
            label5.Text = "Stoped...";
            player.Stop();
            activoCheckBox.Checked = false;
            this.BackColor = Color.WhiteSmoke;
        }

     
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Guardar();
        }

    }


    public static class GuardarDatos
    {

        public static void Guardar(String datos)
        {
            OleDbConnection conexion = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\Despertador.accdb");
            conexion.Open();
            OleDbCommand cmd = conexion.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = datos;


            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();

            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);

            conexion.Close();

        }
    }
}
