﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desepertador
{
    class GuardarReloj
    {
        private string hora;
        private string min;
        private string ruta;



        public string Hora { get => hora; set => hora = value; }
        public string Min { get => min; set => min = value; }
        public string Ruta { get => ruta; set => ruta = value; }

    }
}
