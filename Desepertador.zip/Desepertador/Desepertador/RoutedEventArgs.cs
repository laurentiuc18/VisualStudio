﻿namespace Desepertador
{
    internal class RoutedEventArgs
    {
    }
}